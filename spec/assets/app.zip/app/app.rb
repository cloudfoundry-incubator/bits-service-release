#!/usr/bin/env ruby

require_relative './lib'

hello
